window.onload = start;

/* Start-delen */
function start() {

    const elementYes = document.querySelector('.yes');
    const elementNo = document.querySelector('.no')

    elementYes.addEventListener('click', yes);
    elementNo.addEventListener('click', no);

    
    
    function yes() {
        window.open("https://sv.wikipedia.org/wiki/Adolf_Hitler");
        }
    function no() {
        window.open("https://www.youtube.com/watch?v=LDU_Txk06tM");
    }
    }